--Consider the following schema for Products table. 
--Products(Product_id, Product_Name, Product_Type, Price) 
--1. Write a parameterized cursor to display all products in the given price range of price and type ‘Apparel’. 
--Hint: Take the user input for minimum and maximum price for price range. 
--2. Write an explicit cursor to display information of all products with Price greater than 5000. 
--3. Write an implicit cursor to display the number of records affected by the update operation incrementing Price of all products by 1000. 

-- 1️⃣ CREATE TABLE
CREATE TABLE Products (
    Product_id NUMBER PRIMARY KEY,
    Product_Name VARCHAR2(50),
    Product_Type VARCHAR2(30),
    Price NUMBER
);

-- 2️⃣ INSERT SAMPLE DATA
INSERT INTO Products VALUES (101, 'T-Shirt', 'Apparel', 1500);
INSERT INTO Products VALUES (102, 'Jeans', 'Apparel', 3000);
INSERT INTO Products VALUES (103, 'Shoes', 'Footwear', 7000);
INSERT INTO Products VALUES (104, 'Watch', 'Accessory', 5500);
INSERT INTO Products VALUES (105, 'Jacket', 'Apparel', 6000);
COMMIT;

-- ======================================================
-- 3️⃣ PARAMETERIZED CURSOR:
-- Display all Apparel products in given price range.
-- ======================================================
SET SERVEROUTPUT ON;
DECLARE
    v_min_price NUMBER;
    v_max_price NUMBER;
    v_pid Products.Product_id%TYPE;
    v_name Products.Product_Name%TYPE;
    v_type Products.Product_Type%TYPE;
    v_price Products.Price%TYPE;

    CURSOR cur_apparel(p_min NUMBER, p_max NUMBER) IS
        SELECT Product_id, Product_Name, Product_Type, Price
        FROM Products
        WHERE Product_Type = 'Apparel'
          AND Price BETWEEN p_min AND p_max;
BEGIN
    -- Accept user input
    v_min_price := &Enter_Min_Price;
    v_max_price := &Enter_Max_Price;

    OPEN cur_apparel(v_min_price, v_max_price);
    LOOP
        FETCH cur_apparel INTO v_pid, v_name, v_type, v_price;
        EXIT WHEN cur_apparel%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('ID: '||v_pid||'  Name: '||v_name||'  Type: '||v_type||'  Price: '||v_price);
    END LOOP;
    CLOSE cur_apparel;
END;
/
-- ======================================================
-- 4️⃣ EXPLICIT CURSOR:
-- Display all products with Price > 5000
-- ======================================================
DECLARE
    v_pid Products.Product_id%TYPE;
    v_name Products.Product_Name%TYPE;
    v_type Products.Product_Type%TYPE;
    v_price Products.Price%TYPE;

    CURSOR cur_highprice IS
        SELECT Product_id, Product_Name, Product_Type, Price
        FROM Products
        WHERE Price > 5000;
BEGIN
    OPEN cur_highprice;
    LOOP
        FETCH cur_highprice INTO v_pid, v_name, v_type, v_price;
        EXIT WHEN cur_highprice%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('ID: '||v_pid||'  Name: '||v_name||'  Type: '||v_type||'  Price: '||v_price);
    END LOOP;
    CLOSE cur_highprice;
END;
/
-- ======================================================
-- 5️⃣ IMPLICIT CURSOR:
-- Increment price of all products by 1000
-- and display number of rows affected.
-- ======================================================
BEGIN
    UPDATE Products
    SET Price = Price + 1000;

    DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' rows updated successfully.');
END;
/
-- ======================================================
-- 6️⃣ VERIFY TABLE CONTENT
SELECT * FROM Products;
