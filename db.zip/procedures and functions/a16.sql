--Employee( emp_id, dept_idemp_name, DoJ, salary, commission,job_title) 
--1. Consider the schema given above. Keep the commission column empty initially. Write a Stored Procedure to 
--record the employee commission based on following conditions. If salary is more than 10000 then commission 
--is 0.4%, if Salary is less than 10000 but experience is more than 10 years then 0.35%, if salary is less than 3000 
--then commission is 0.25%. In the remaining cases commission is 0.15%. 
--2. Write a PLSQL Function that takes department ID and returns the name of the manager of the department. 



CREATE TABLE Employee (
    emp_id NUMBER PRIMARY KEY,
    dept_id NUMBER,
    emp_name VARCHAR2(50),
    doj DATE,              -- Date of Joining
    salary NUMBER,
    commission NUMBER,      -- Initially NULL
    job_title VARCHAR2(50)
);

-- Sample Data
INSERT INTO Employee VALUES (101, 10, 'Amit', TO_DATE('15-APR-2010','DD-MON-YYYY'), 50000, NULL, 'Manager');
INSERT INTO Employee VALUES (102, 20, 'Riya', TO_DATE('01-JAN-2015','DD-MON-YYYY'), 6000, NULL, 'Developer');
INSERT INTO Employee VALUES (115, 30, 'Rahul', TO_DATE('01-JUN-2008','DD-MON-YYYY'), 2000, NULL, 'Team Lead');
INSERT INTO Employee VALUES (104, 40, 'Sneha', TO_DATE('10-MAR-2020','DD-MON-YYYY'), 8000, NULL, 'Analyst');
INSERT INTO Employee VALUES (105, 10, 'Vikram', TO_DATE('01-JAN-2005','DD-MON-YYYY'), 9000, NULL, 'Manager');
COMMIT;

CREATE OR REPLACE PROCEDURE Calculate_Commission IS
    v_salary Employee.salary%TYPE;
    v_doj Employee.doj%TYPE;
    v_exp NUMBER;
BEGIN
    FOR emp IN (SELECT emp_id, salary, doj FROM Employee) LOOP
        v_salary := emp.salary;
        v_doj := emp.doj;
        v_exp := FLOOR(MONTHS_BETWEEN(SYSDATE, v_doj)/12);  -- Calculate experience in years

        IF v_salary > 10000 THEN
            UPDATE Employee
            SET commission = v_salary * 0.004
            WHERE emp_id = emp.emp_id;
        ELSIF v_salary < 10000 AND v_exp > 10 THEN
            UPDATE Employee
            SET commission = v_salary * 0.0035
            WHERE emp_id = emp.emp_id;
        ELSIF v_salary < 3000 THEN
            UPDATE Employee
            SET commission = v_salary * 0.0025
            WHERE emp_id = emp.emp_id;
        ELSE
            UPDATE Employee
            SET commission = v_salary * 0.0015
            WHERE emp_id = emp.emp_id;
        END IF;
    END LOOP;

    COMMIT;
END;
/

CREATE OR REPLACE FUNCTION Get_Manager(p_dept_id NUMBER) 
RETURN VARCHAR2 IS
    v_manager_name Employee.emp_name%TYPE;
BEGIN
    SELECT emp_name INTO v_manager_name
    FROM Employee
    WHERE dept_id = p_dept_id
      AND LOWER(job_title) LIKE '%manager%'  -- Manager identification
      AND ROWNUM = 1;                       -- In case multiple managers

    RETURN v_manager_name;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'No Manager Found';
END;
/

-- Run the procedure to calculate commission
BEGIN
    Calculate_Commission;
END;
/

-- Check the commission
SELECT emp_id, emp_name, salary, commission FROM Employee;

-- Test the function for department 10
DECLARE
    v_mgr_name VARCHAR2(50);
BEGIN
    v_mgr_name := Get_Manager(10);
    DBMS_OUTPUT.PUT_LINE('Manager of Dept 10: ' || v_mgr_name);
END;
/


