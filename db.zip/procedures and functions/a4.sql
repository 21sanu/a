--Consider following schema for Bank database. 
--Account(Account_No, Cust_Name, Balance, NoOfYears) 
--Earned_Interest(Account_No, Interest_Amt) 
--1. Write a PL/SQL procedure for following requirement. Take as input Account_No and Interest Rate from User. 
--Calculate the Interest_Amt as simple interest for the given Account_No and store it in Earned_Interest table. 
--Display all the details of Earned_Interest Table. 
--2. Write a PLSQL function to display all records from Account table having Balance greater than 50,000. 



-- Create tables
CREATE TABLE Account(
  Account_No NUMBER PRIMARY KEY,
  Cust_Name VARCHAR2(50),
  Balance NUMBER,
  NoOfYears NUMBER
);

CREATE TABLE Earned_Interest(
  Account_No NUMBER REFERENCES Account(Account_No),
  Interest_Amt NUMBER
);

-- Sample data
INSERT INTO Account VALUES(101,'Amit Sharma',45000,2);
INSERT INTO Account VALUES(102,'Riya Mehta',80000,3);
INSERT INTO Account VALUES(103,'Karan Patil',60000,1);
INSERT INTO Account VALUES(104,'Sneha Joshi',30000,4);
INSERT INTO Account VALUES(105,'Rahul Verma',100000,5);
COMMIT;


CREATE OR REPLACE PROCEDURE Calculate_Interest(
  p_acc_no IN NUMBER, p_rate IN NUMBER)
IS
  v_bal Account.Balance%TYPE;
  v_years Account.NoOfYears%TYPE;
  v_interest NUMBER;
BEGIN
  SELECT Balance, NoOfYears INTO v_bal, v_years
  FROM Account WHERE Account_No = p_acc_no;

  v_interest := (v_bal * p_rate * v_years)/100;

  INSERT INTO Earned_Interest VALUES(p_acc_no, v_interest);
  COMMIT;

  DBMS_OUTPUT.PUT_LINE('Interest calculated for Acc_No '||p_acc_no);

  FOR r IN (SELECT * FROM Earned_Interest) LOOP
    DBMS_OUTPUT.PUT_LINE('Acc_No:'||r.Account_No||'  Interest:'||r.Interest_Amt);
  END LOOP;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Invalid Account Number!');
END;
/
BEGIN
  Calculate_Interest(102,5);
END;
/
CREATE OR REPLACE FUNCTION High_Balance_Accounts
RETURN SYS_REFCURSOR IS
  c SYS_REFCURSOR;
BEGIN
  OPEN c FOR SELECT * FROM Account WHERE Balance>50000;
  RETURN c;
END;
/
DECLARE
  c SYS_REFCURSOR;
  v1 NUMBER; v2 VARCHAR2(50); v3 NUMBER; v4 NUMBER;
BEGIN
  c := High_Balance_Accounts;
  DBMS_OUTPUT.PUT_LINE('--- High Balance Accounts ---');
  LOOP
    FETCH c INTO v1,v2,v3,v4;
    EXIT WHEN c%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('AccNo:'||v1||' Name:'||v2||' Balance:'||v3);
  END LOOP;
  CLOSE c;
END;
/
SELECT * FROM Earned_Interest;
SELECT * FROM Account;

