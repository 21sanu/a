--Employee(emp_id, emp_name, salary, designation) 
--Salary_Backup(emp_id, old_salary, new_salary, salary_difference) 
--Create a Trigger to record salary change of the employee. Whenever salary is updated insert the details in Salary_Backup table. 
--Create a Trigger that will prevent deleting the employee record having designation as CEO. 


-- Step 1: Create Employee Table
CREATE TABLE Employee (
    emp_id NUMBER PRIMARY KEY,
    emp_name VARCHAR2(50),
    salary NUMBER,
    designation VARCHAR2(50)
);
-- Step 2: Create Salary_Backup Table
CREATE TABLE Salary_Backup (
    emp_id NUMBER,
    old_salary NUMBER,
    new_salary NUMBER,
    salary_difference NUMBER
);

-- Step 3: Insert Sample Data into Employee
INSERT INTO Employee VALUES (1, 'Amit', 50000, 'Manager');
INSERT INTO Employee VALUES (2, 'Riya', 90000, 'CEO');
INSERT INTO Employee VALUES (3, 'Rahul', 60000, 'Developer');
COMMIT;

-- Step 4: Trigger 1 - Record Salary Change
CREATE OR REPLACE TRIGGER trg_salary_change
BEFORE UPDATE OF salary ON Employee
FOR EACH ROW
BEGIN
    INSERT INTO Salary_Backup (emp_id, old_salary, new_salary, salary_difference)
    VALUES (:OLD.emp_id, :OLD.salary, :NEW.salary, :NEW.salary - :OLD.salary);
END;
/

-- Step 5: Trigger 2 - Prevent CEO Deletion
CREATE OR REPLACE TRIGGER trg_prevent_ceo_delete
BEFORE DELETE ON Employee
FOR EACH ROW
BEGIN
    IF :OLD.designation = 'CEO' THEN
        RAISE_APPLICATION_ERROR(-20001, 'Cannot delete record of the CEO.');
    END IF;
END;
/

-- Step 6: Test Salary Update Trigger
UPDATE Employee SET salary = 65000 WHERE emp_id = 3;

-- Step 7: View Salary_Backup Table
SELECT * FROM Salary_Backup;

-- Step 8: Attempt to Delete CEO (should raise error)
DELETE FROM Employee WHERE designation = 'CEO';

-- Step 9: View Employee Table After Update/Delete
SELECT * FROM Employee;
