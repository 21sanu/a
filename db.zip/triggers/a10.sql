--Employee( emp_id, dept_idemp_name, DoJ, salary, commission,job_title) 
--Consider the schema given above for Write a PLSQL Program to 
--1. Create a Trigger to ensure the salary of the employee is not decreased. 
--2. Whenever the job title is changed for an employee write the following details into job_history table. 
--Employee ID, old job title, old department ID, DoJ for start date, system date for end date.  


-- Step 1: Create Required Tables
CREATE TABLE Employee (
    emp_id NUMBER PRIMARY KEY,
    dept_id NUMBER,
    emp_name VARCHAR2(50),
    DoJ DATE,
    salary NUMBER,
    commission NUMBER,
    job_title VARCHAR2(50)
);

CREATE TABLE Job_History (
    emp_id NUMBER,
    old_job_title VARCHAR2(50),
    old_dept_id NUMBER,
    start_date DATE,
    end_date DATE
);

-- Step 2: Insert Sample Data
INSERT INTO Employee VALUES (1, 101, 'Amit', TO_DATE('10-JAN-2020', 'DD-MON-YYYY'), 50000, 5000, 'Developer');
INSERT INTO Employee VALUES (2, 102, 'Riya', TO_DATE('15-MAR-2021', 'DD-MON-YYYY'), 70000, 7000, 'Analyst');
INSERT INTO Employee VALUES (3, 103, 'Rahul', TO_DATE('01-JUN-2022', 'DD-MON-YYYY'), 60000, 6000, 'Tester');

COMMIT;

-- Step 3: Trigger to Prevent Salary Decrease
CREATE OR REPLACE TRIGGER trg_prevent_salary_decrease
BEFORE UPDATE OF salary ON Employee
FOR EACH ROW
BEGIN
    IF :NEW.salary < :OLD.salary THEN
        RAISE_APPLICATION_ERROR(-20002, 'Salary cannot be decreased!');
    END IF;
END;
/

-- Step 4: Trigger to Record Job Title Change in Job_History
CREATE OR REPLACE TRIGGER trg_job_history
BEFORE UPDATE OF job_title ON Employee
FOR EACH ROW
BEGIN
    INSERT INTO Job_History (emp_id, old_job_title, old_dept_id, start_date, end_date)
    VALUES (:OLD.emp_id, :OLD.job_title, :OLD.dept_id, :OLD.DoJ, SYSDATE);
END;
/

-- Step 5: Test the Triggers

-- 1️⃣ Test Salary Decrease (This will raise an error)
UPDATE Employee SET salary = 40000 WHERE emp_id = 1;

-- 2️⃣ Test Job Title Change (This will insert into Job_History)
UPDATE Employee SET job_title = 'Senior Developer' WHERE emp_id = 1;

-- Step 6: View Results
SELECT * FROM Employee;
SELECT * FROM Job_History;


