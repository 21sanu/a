--Consider a table Employee with schema as Employee (Emp_id, Emp_Name,Salary). 
--1. Write an explicit cursor to display records of all employees with salary greater than 50,000. 
--2. Write a PL/SQL block of code using Implicit Cursor that will display total number of tuples in Employee table. 
--3. Write a PL/SQL block of code using Parameterized Cursor that will display salary of employee id entered by the user.


-- ======================================================
-- PRACTICAL: CURSORS IN PL/SQL
-- TOPIC: EMPLOYEE TABLE
-- ======================================================

-- 1️⃣ CREATE TABLE
CREATE TABLE Employee (
    Emp_id NUMBER PRIMARY KEY,
    Emp_Name VARCHAR2(50),
    Salary NUMBER
);

-- 2️⃣ INSERT SAMPLE DATA
INSERT INTO Employee VALUES (101, 'Amit', 45000);
INSERT INTO Employee VALUES (102, 'Riya', 75000);
INSERT INTO Employee VALUES (103, 'Neha', 52000);
INSERT INTO Employee VALUES (104, 'Raj', 49000);
INSERT INTO Employee VALUES (105, 'Sam', 90000);
COMMIT;

-- Enable output
SET SERVEROUTPUT ON;

-- ======================================================
-- 3️⃣ EXPLICIT CURSOR
-- Display records of all employees with salary > 50000
-- ======================================================
DECLARE
    v_id Employee.Emp_id%TYPE;
    v_name Employee.Emp_Name%TYPE;
    v_salary Employee.Salary%TYPE;

    CURSOR cur_highsal IS
        SELECT Emp_id, Emp_Name, Salary
        FROM Employee
        WHERE Salary > 50000;
BEGIN
    OPEN cur_highsal;
    LOOP
        FETCH cur_highsal INTO v_id, v_name, v_salary;
        EXIT WHEN cur_highsal%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('ID: '||v_id||'  Name: '||v_name||'  Salary: '||v_salary);
    END LOOP;
    CLOSE cur_highsal;
END;
/
-- ======================================================
-- 4️⃣ IMPLICIT CURSOR
-- Display total number of employees (tuples)
-- ======================================================
DECLARE
    v_total NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_total FROM Employee;
    DBMS_OUTPUT.PUT_LINE('Total number of employees: ' || v_total);
END;
/
-- ======================================================
-- 5️⃣ PARAMETERIZED CURSOR
-- Display salary of employee for user-entered ID
-- ======================================================
DECLARE
    v_emp_id NUMBER;
    v_salary Employee.Salary%TYPE;

    CURSOR cur_salary(p_id NUMBER) IS
        SELECT Salary FROM Employee WHERE Emp_id = p_id;

BEGIN
    -- Accept employee ID from user
    v_emp_id := &Enter_Emp_ID;

    OPEN cur_salary(v_emp_id);
    FETCH cur_salary INTO v_salary;

    IF cur_salary%FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Salary of Employee ID '||v_emp_id||' is: '||v_salary);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Employee ID '||v_emp_id||' not found.');
    END IF;

    CLOSE cur_salary;
END;
/
