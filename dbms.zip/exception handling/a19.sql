--Employee( emp_id, dept_idemp_name, DoJ, salary, commission,job_title) 
--Salary_Increment(emp_id, new_salary) 
--Consider the schema given above. Write a PLSQL Unnamed Block of code to increase the salary of employee 115 based on the following conditions: 
--Accept emp_id from user. If experience of employee is more than 10 years, increase salary by 20%.
--If experience is greater than 5 years, increase salary by 10% Otherwise 5%. (Hint: Find the years of experience from Date of Joining (DoJ)).
--Store the incremented salary in Salary_Increment table. 
--Also handle the exception by named exception handler or user defined exception handler. 

-- Step 1: Create Employee Table
CREATE TABLE Employee (
    emp_id NUMBER PRIMARY KEY,
    dept_id NUMBER,
    emp_name VARCHAR2(50),
    doj DATE,              -- Date of Joining
    salary NUMBER,
    commission NUMBER,
    job_title VARCHAR2(50)
);

-- Step 2: Create Salary_Increment Table
CREATE TABLE Salary_Increment (
    emp_id NUMBER,
    new_salary NUMBER
);

-- Step 3: Insert Sample Data
INSERT INTO Employee VALUES (101, 10, 'Amit', TO_DATE('15-APR-2010','DD-MON-YYYY'), 50000, 5000, 'Manager');
INSERT INTO Employee VALUES (102, 20, 'Riya', TO_DATE('01-JAN-2015','DD-MON-YYYY'), 60000, 6000, 'Developer');
INSERT INTO Employee VALUES (115, 30, 'Rahul', TO_DATE('01-JUN-2008','DD-MON-YYYY'), 70000, 7000, 'Team Lead');
INSERT INTO Employee VALUES (104, 40, 'Sneha', TO_DATE('10-MAR-2020','DD-MON-YYYY'), 40000, 4000, 'Analyst');
COMMIT;

-- Step 4: PL/SQL Unnamed Block to Increment Salary
DECLARE
    v_emp_id Employee.emp_id%TYPE;       -- Employee ID input by user
    v_salary Employee.salary%TYPE;       -- Current salary
    v_doj Employee.doj%TYPE;             -- Date of Joining
    v_exp NUMBER;                        -- Years of experience
    v_new_salary NUMBER;                 -- Incremented salary
    v_count NUMBER;                      -- To check if employee exists

    -- User-defined exception if employee not found
    emp_not_found EXCEPTION;

BEGIN
    -- Accept Employee ID from user
    v_emp_id := &Enter_Emp_ID;

    -- Check if employee exists
    SELECT COUNT(*) INTO v_count
    FROM Employee
    WHERE emp_id = v_emp_id;

    IF v_count = 0 THEN
        RAISE emp_not_found;
    END IF;

    -- Fetch current salary and Date of Joining
    SELECT salary, doj
    INTO v_salary, v_doj
    FROM Employee
    WHERE emp_id = v_emp_id;

    -- Calculate years of experience
    v_exp := FLOOR(MONTHS_BETWEEN(SYSDATE, v_doj)/12);

    -- Apply increment rules
    IF v_exp > 10 THEN
        v_new_salary := v_salary * 1.20;
    ELSIF v_exp > 5 THEN
        v_new_salary := v_salary * 1.10;
    ELSE
        v_new_salary := v_salary * 1.05;
    END IF;

    -- Insert new salary into Salary_Increment table
    INSERT INTO Salary_Increment(emp_id, new_salary)
    VALUES(v_emp_id, v_new_salary);

    COMMIT;

    -- Display success message
    DBMS_OUTPUT.PUT_LINE('Salary incremented successfully for Emp ID: ' || v_emp_id);
    DBMS_OUTPUT.PUT_LINE('Years of Experience: ' || v_exp);
    DBMS_OUTPUT.PUT_LINE('New Salary: ' || v_new_salary);

EXCEPTION
    -- Handle employee not found
    WHEN emp_not_found THEN
        DBMS_OUTPUT.PUT_LINE('Error: Employee ID ' || v_emp_id || ' not found.');

    -- Handle any other unexpected errors
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Unexpected Error: ' || SQLERRM);
END;
/

select * from Salary_Increment;

drop table Employee;
drop table Salary_Increment;

